package com.ders.kilidi

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Calendar

// Bir kilit saat aralığı: dakika olarak başlangıç/bitiş, açık/kapalı ve katı mod
data class Sch(val id: Long, val st: Int, val en: Int, val on: Boolean, val strict: Boolean) {
    // Gece yarısını geçen aralıklar (örn. 22:00–06:00) de desteklenir
    fun contains(m: Int) = if (st <= en) m in st until en else m >= st || m < en
}

// Kilit ayarlarının tek doğruluk kaynağı. Web sayfası yalnızca Bridge üzerinden yazabilir.
class Store(c: Context) {
    private val p = c.getSharedPreferences("s", Context.MODE_PRIVATE)

    companion object {
        fun mins(t: String): Int { val q = t.split(":"); return q[0].toInt() * 60 + q[1].toInt() }
        fun parse(a: JSONArray): List<Sch> = (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Sch(o.optLong("id", it.toLong()), mins(o.getString("st")), mins(o.getString("en")), true, o.optBoolean("strict"))
        }
    }

    private fun hm(m: Int) = "%02d:%02d".format(m / 60, m % 60)

    // Saat aralıkları JSON olarak saklanır; eski tek aralıklı ayar ilk okumada dönüştürülür
    var schJson: String
        get() = p.getString("sch", null) ?: if (p.getBoolean("on", false)) JSONArray().put(
            JSONObject().put("id", 1).put("st", hm(p.getInt("st", 8 * 60))).put("en", hm(p.getInt("en", 22 * 60)))
                .put("on", true).put("strict", false)
        ).toString() else "[]"
        set(v) { p.edit().putString("sch", v).apply() }

    fun schedules(): List<Sch> = try { parse(JSONArray(schJson)) } catch (e: Exception) { emptyList() }

    // Her aralık saati gelince kendiliğinden devreye girer (elle açma/kapama yok); en az bir aralık varsa kilit sistemi çalışır
    val lockOn: Boolean get() = schedules().isNotEmpty()

    var apps: Set<String>
        get() = HashSet(p.getStringSet("apps", emptySet())!!)
        set(v) { p.edit().putStringSet("apps", v).apply() }

    // Saat geri alınarak kilidi atlatmayı önlemek için görülen en ileri zaman damgası
    fun touch(now: Long) { if (now > p.getLong("maxT", 0)) p.edit().putLong("maxT", now).apply() }
    fun clockBack(now: Long = System.currentTimeMillis()) = now < p.getLong("maxT", 0) - 120_000

    // Mola sistemi: her 30 dk'lık blokta en fazla 1 kez 5 dk mola. Blok kimliği tarih+yarım saat olduğundan 00:00'da kendiliğinden sıfırlanır.
    fun block(): Int {
        val c = Calendar.getInstance()
        return (c.get(Calendar.YEAR) * 400 + c.get(Calendar.DAY_OF_YEAR)) * 48 +
            c.get(Calendar.HOUR_OF_DAY) * 2 + c.get(Calendar.MINUTE) / 30
    }
    fun breakUsed() = p.getInt("bb", -1) == block()
    fun grantBreak(): Boolean {
        if (clockBack() || breakUsed()) return false
        p.edit().putInt("bb", block()).putLong("bu", System.currentTimeMillis() + 5 * 60_000L).apply()
        return true
    }
    fun onBreak() = !clockBack() && p.getLong("bu", 0) > System.currentTimeMillis()

    private fun nowMin(): Int { val c = Calendar.getInstance(); return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE) }

    // Açık aralıklardan biri şu an geçerli mi? (saat geri alma da kilitli sayılır)
    fun inWindow(): Boolean = clockBack() || schedules().any { it.contains(nowMin()) }

    // Şu an geçerli, açık ve katı modlu bir aralık var mı? (Ayarlar ve uygulama yükleyici bu sırada kilitlenir)
    fun strictActive(): Boolean {
        val cb = clockBack(); val m = nowMin()
        return schedules().any { it.strict && (cb || it.contains(m)) }
    }

    // Kilit açık ve kilit saatindeyse ayarlar değiştirilemez
    fun locked() = lockOn && inWindow()

    // ---- Katı mod şifresi (SHA-256 + tuz; 5 yanlışta 1 dk bekleme) ----
    fun hasPin() = p.getString("pinH", null) != null
    private fun hash(salt: String, pin: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }
    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        p.edit().putString("pinS", salt).putString("pinH", hash(salt, pin)).apply()
    }
    fun checkPin(pin: String): Boolean {
        val now = System.currentTimeMillis()
        if (p.getLong("pfUntil", 0) > now) return false
        val ok = hash(p.getString("pinS", "")!!, pin) == p.getString("pinH", null)
        val e = p.edit()
        if (ok) e.putInt("pf", 0).putLong("pinOK", now + 120_000L)
        else {
            val f = p.getInt("pf", 0) + 1
            e.putInt("pf", if (f >= 5) 0 else f)
            if (f >= 5) e.putLong("pfUntil", now + 60_000L)
        }
        e.apply()
        return ok
    }
    // Şifre doğru girildikten sonra 2 dk boyunca korumalı bir değişiklik yapılabilir
    fun pinOpen() = !clockBack() && p.getLong("pinOK", 0) > System.currentTimeMillis()
    fun closePin() { p.edit().putLong("pinOK", 0).apply() }
}
