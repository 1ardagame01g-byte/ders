package com.ders.kilidi

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Process
import android.provider.Settings
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject

// Web sayfasının "DersKilidiNative" adıyla gördüğü yerel köprü
class Bridge(private val c: Context) {

    // Telefonda başlatıcıda görünen tüm uygulamalar: [{"n":"WhatsApp","p":"com.whatsapp"}, ...]
    @JavascriptInterface
    fun getApps(): String {
        val pm = c.packageManager
        val arr = JSONArray()
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != c.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
            .forEach { arr.put(JSONObject().put("n", it.first).put("p", it.second)) }
        return arr.toString()
    }

    @JavascriptInterface
    fun perms(): String {
        val usage = c.getSystemService(AppOpsManager::class.java)
            .unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
        return JSONObject().put("usage", usage).put("overlay", Settings.canDrawOverlays(c)).toString()
    }

    @JavascriptInterface
    fun openSettings(w: String) {
        val i = if (w == "usage") Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        else Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}"))
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    @JavascriptInterface
    fun getLock(): String {
        val s = Store(c)
        return JSONObject().put("sch", JSONArray(s.schJson)).put("apps", JSONArray(s.apps.toList()))
            .put("hasPin", s.hasPin()).toString()
    }

    // Kilit saatindeyken hiçbir değişiklik kabul edilmez. Açık + katı modlu bir aralığı değiştirmek/silmek/kapatmak
    // ya da (böyle bir aralık varken) uygulama listesini değiştirmek için az önce doğru şifre girilmiş olmalıdır.
    @JavascriptInterface
    fun setLock(json: String): Boolean {
        val s = Store(c)
        if (s.locked()) return false
        return try {
            val o = JSONObject(json)
            val a = o.getJSONArray("apps")
            val newApps = (0 until a.length()).map { a.getString(it) }.toSet()
            val newSch = o.getJSONArray("sch")
            val nl = Store.parse(newSch)
            if (nl.size > 10) return false
            val protectedOld = s.schedules().filter { it.strict }
            val needPin = protectedOld.isNotEmpty() && (newApps != s.apps || protectedOld.any { ov -> nl.none { it == ov } })
            if (needPin && !s.pinOpen()) return false
            if (nl.any { it.strict } && !s.hasPin()) return false
            s.schJson = newSch.toString()
            s.apps = newApps
            if (needPin) s.closePin()
            if (s.lockOn) c.startForegroundService(Intent(c, LockService::class.java))
            true
        } catch (e: Exception) { false }
    }

    @JavascriptInterface
    fun hasPin(): Boolean = Store(c).hasPin()

    @JavascriptInterface
    fun checkPin(pin: String): Boolean = Store(c).checkPin(pin)

    // İlk şifre serbestçe konur; sonradan değiştirmek için önce doğru şifre girilmiş olmalı ve kilit saatinde olunmamalı
    @JavascriptInterface
    fun setPin(pin: String): Boolean {
        val s = Store(c)
        if (pin.length < 4 || pin.length > 64 || s.locked()) return false
        if (s.hasPin() && !s.pinOpen()) return false
        s.setPin(pin)
        return true
    }

    // Blok başına 1 kez 5 dk mola; hakkı yerel Store belirler (sıkı mod paketleri molada da kilitli kalır)
    @JavascriptInterface
    fun grantBreak(): Boolean = Store(c).grantBreak()

    @JavascriptInterface
    fun getBreak(): String = JSONObject().put("used", Store(c).breakUsed()).toString()

    @JavascriptInterface
    fun openApp(pkg: String) {
        c.packageManager.getLaunchIntentForPackage(pkg)?.let { c.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    @JavascriptInterface
    fun goHome() {
        c.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun hm(m: Int) = "%02d:%02d".format(m / 60, m % 60)
    private fun min(t: String): Int { val p = t.split(":"); return p[0].toInt() * 60 + p[1].toInt() }
}
