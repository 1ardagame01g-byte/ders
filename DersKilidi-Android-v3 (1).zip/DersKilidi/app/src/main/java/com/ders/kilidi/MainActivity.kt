package com.ders.kilidi

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var cb: ValueCallback<Array<Uri>>? = null
    private var pending: String? = null   // kilitli uygulama için çözülecek soru isteği
    private var loaded = false
    private val pick = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { u ->
        cb?.onReceiveValue(u.toTypedArray()); cb = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pending = intent.getStringExtra("unlock")
        // Servis sistem tarafından kapatıldıysa uygulama açılınca yeniden başlat
        if (Store(this).lockOn) startForegroundService(Intent(this, LockService::class.java))
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, u: String) { loaded = true; deliver() }
            // Hoca önerileri gibi dış bağlantılar uygulamanın içinde değil, YouTube/tarayıcıda açılır
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == "appassets.androidplatform.net") return false
                startActivity(Intent(Intent.ACTION_VIEW, r.url))
                return true
            }
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(r.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, f: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                cb?.onReceiveValue(null); cb = f
                pick.launch(arrayOf("*/*"))
                return true
            }
        }
        web.addJavascriptInterface(Bridge(applicationContext), "DersKilidiNative")
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        pending = i.getStringExtra("unlock")
        deliver()
    }

    private fun deliver() {
        val p = pending
        if (!loaded || p == null || !::web.isInitialized) return
        pending = null
        val safe = p.replace(Regex("[^A-Za-z0-9._]"), "")
        web.evaluateJavascript("window.nativeUnlock&&window.nativeUnlock('$safe')", null)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.nativeResume&&window.nativeResume()", null)
        deliver()
    }
}
