package com.ders.kilidi

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.*
import java.util.Calendar

class LockService : Service() {
    companion object {
        // Sıkı modda kilit saatinde bunlar da kilitlenir (izinleri kapatmayı ve uygulamayı silmeyi zorlaştırır)
        val STRICT = setOf(
            "com.android.settings", "com.android.packageinstaller",
            "com.google.android.packageinstaller", "com.samsung.android.packageinstaller"
        )
    }

    private val h = Handler(Looper.getMainLooper())
    private var cur: String? = null          // şu an ön plandaki paket (kilit saati başlayınca da kontrol edilir)
    private var t0 = System.currentTimeMillis()
    private var lastLaunch = 0L
    private var warned = false
    private var registered = false
    private val tick = object : Runnable {
        override fun run() { h.postDelayed(this, check()) }
    }

    // Ekran açılınca ya da saat değişince beklemeden hemen kontrol et (uyku modunda zamanlayıcı gecikse bile kilit kaçmaz)
    private val wake = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { h.removeCallbacks(tick); h.post(tick) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("k", "Kilit", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "k").setContentTitle("Ders kilidi aktif")
            .setSmallIcon(android.R.drawable.ic_lock_lock).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        if (!registered) {
            val flt = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_USER_PRESENT)
                addAction(Intent.ACTION_TIME_CHANGED); addAction(Intent.ACTION_TIMEZONE_CHANGED); addAction(Intent.ACTION_DATE_CHANGED)
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(wake, flt, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(wake, flt)
            registered = true
        }
        h.removeCallbacks(tick); h.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        if (registered) { try { unregisterReceiver(wake) } catch (e: Exception) {}; registered = false }
    }

    // Bir sonraki dakika başına kalan süre (ms): kilit saati dışında dakikada bir kontrol (pil dostu, saat değişikliğini en geç 1 dk'da yakalar)
    private fun toNextMinute(): Long {
        val n = Calendar.getInstance()
        val now = n.timeInMillis
        n.add(Calendar.MINUTE, 1); n.set(Calendar.SECOND, 0); n.set(Calendar.MILLISECOND, 0)
        return (n.timeInMillis - now + 200).coerceIn(500L, 60_300L)
    }

    private fun hasUsage() = getSystemService(AppOpsManager::class.java)
        .unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED

    private fun warn() {
        if (warned) return
        warned = true
        val n = Notification.Builder(this, "k").setContentTitle("Ders kilidi çalışmıyor")
            .setContentText("Kullanım erişimi izni kapalı. Uygulamayı açıp izni ver.")
            .setSmallIcon(android.R.drawable.ic_dialog_alert).build()
        getSystemService(NotificationManager::class.java).notify(2, n)
    }

    // Bir sonraki kontrole kadar beklenecek süreyi (ms) döndürür: kilit saatinde sık, dışında seyrek (pil tasarrufu)
    private fun check(): Long {
        val s = Store(this)
        if (!s.lockOn) { stopSelf(); return 60_000 }
        if (!hasUsage()) { warn(); return 30_000 }
        if (warned) { warned = false; getSystemService(NotificationManager::class.java).cancel(2) }
        val now = System.currentTimeMillis()
        val active = s.inWindow()
        s.touch(now)
        // Kilit saati dışında dakikada bir (dakika başında) kontrol edilir; kilit saatinde uygulama kontrolü saniyede bir yapılır
        if (!active) return toNextMinute()
        val ev = getSystemService(UsageStatsManager::class.java).queryEvents(minOf(t0, now), now)
        t0 = now
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) cur = e.packageName
        }
        val l = cur
        val interactive = getSystemService(PowerManager::class.java).isInteractive
        if (l != null && active && interactive && now - lastLaunch > 3_000 &&
            ((l in s.apps && !s.onBreak()) || (s.strictActive() && l in STRICT))) {
            lastLaunch = now
            startActivity(
                Intent(this, LockActivity::class.java).putExtra("pkg", l)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
        }
        return 1_000
    }
}
