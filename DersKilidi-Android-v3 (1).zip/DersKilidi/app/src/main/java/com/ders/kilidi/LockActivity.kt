package com.ders.kilidi

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback

class LockActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pkg = intent.getStringExtra("pkg") ?: ""
        val name = try { packageManager.getApplicationInfo(pkg, 0).loadLabel(packageManager).toString() } catch (e: Exception) { pkg }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(64, 64, 64, 64)
        }
        fun tv(t: String, sz: Float) = TextView(this).apply { text = t; textSize = sz; gravity = Gravity.CENTER; setPadding(0, 12, 0, 12) }
        col.addView(tv("📚", 56f))
        col.addView(tv("Şimdi ders zamanı", 26f))
        col.addView(tv("$name kilitli.", 16f))
        val strictPkg = pkg in LockService.STRICT
        col.addView(Button(this).apply {
            text = if (strictPkg) "Derse geç" else "Soru çöz, mola kazan"
            setOnClickListener {
                val i = Intent(this@LockActivity, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                if (!strictPkg) i.putExtra("unlock", pkg)
                startActivity(i); finish()
            }
        })
        col.addView(Button(this).apply { text = "Ana ekrana dön"; setOnClickListener { home() } })
        setContentView(col)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { home() }
        })
    }

    private fun home() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
