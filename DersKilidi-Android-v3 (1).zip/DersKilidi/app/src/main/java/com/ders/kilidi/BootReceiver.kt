package com.ders.kilidi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Store(c).lockOn) c.startForegroundService(Intent(c, LockService::class.java))
    }
}
